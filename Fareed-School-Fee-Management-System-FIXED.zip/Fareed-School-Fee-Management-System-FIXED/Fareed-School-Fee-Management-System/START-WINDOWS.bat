@echo off
title Fareed - School Fee Management System
echo Starting Fareed's School Fee Management System...
if not exist node_modules (
  echo Dependencies are missing. Run npm install first.
  pause
  exit /b 1
)
node server.js
pause
