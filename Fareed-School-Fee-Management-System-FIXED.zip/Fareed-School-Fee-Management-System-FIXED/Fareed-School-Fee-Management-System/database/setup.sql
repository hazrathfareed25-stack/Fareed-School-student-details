-- FAREED'S SCHOOL FEE MANAGEMENT SYSTEM
-- Uses the existing database and student table shown in MySQL Workbench.
USE school;

-- Existing table expected:
-- student(student_id, student_name, class, total, age, phone)
-- This script does not drop or overwrite existing student records.

CREATE TABLE IF NOT EXISTS fee_details (
  fee_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  academic_year VARCHAR(20) NOT NULL,
  fee_type VARCHAR(50) NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  due_date DATE NOT NULL,
  CONSTRAINT fk_fee_student FOREIGN KEY (student_id)
    REFERENCES student(student_id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  fee_id INT NOT NULL,
  amount_paid DECIMAL(10,2) NOT NULL,
  payment_date DATE NOT NULL,
  payment_method VARCHAR(30) NOT NULL,
  receipt_no VARCHAR(50) NOT NULL UNIQUE,
  CONSTRAINT fk_payment_fee FOREIGN KEY (fee_id)
    REFERENCES fee_details(fee_id) ON DELETE RESTRICT,
  CONSTRAINT chk_payment_amount CHECK (amount_paid > 0)
);

SHOW TABLES;
SELECT * FROM student;
