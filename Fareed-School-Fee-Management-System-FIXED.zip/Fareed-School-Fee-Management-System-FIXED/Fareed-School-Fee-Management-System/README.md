# Fareed's School Fee Management System

A school fee management web application using Node.js, Express, MySQL, HTML, CSS and JavaScript. The interface uses a custom neo-brutalism + soft neumorphic visual style, with responsive layouts and small motion effects.

## Features
- Dashboard totals: students, assigned fees, collected amount and pending amount
- Student management using the existing `school.student` table
- Fee assignment by academic year and fee type
- Full or partial payment recording with unique receipt numbers
- Balance validation to prevent overpayment
- Student fee reports and CSV export
- Responsive UI, custom Fareed logo asset and animated interactions

## Database setup
This project is configured for the existing MySQL database named `school` and the existing student table shown in the supplied screenshot:

`student(student_id, student_name, class, total, age, phone)`

1. Open MySQL Workbench and select/open the `school` schema.
2. Open `database/setup.sql` and execute it. It creates only `fee_details` and `payments`; it does not drop or replace student records.
3. Confirm that the `student` table uses InnoDB and that `student_id` is a primary key.

## Run locally
1. Install Node.js LTS and MySQL Server. Make sure the MySQL service is running and that the MySQL `root` account password is `fareed@06` (or update `.env` to match your actual password).
2. Copy `.env.example` to `.env`.
3. Set `DB_USER` and `DB_PASSWORD` to your local MySQL credentials. Keep `DB_NAME=school`.
4. In the project folder run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Notes
- This is a local academic project starter, not a production-ready financial system.
- Add administrator authentication, backups, audit logs and receipt printing before real-world deployment.
- Student deletion is restricted when fee records exist, to protect payment history.


## Important password note
The included `.env` is configured with the password requested for this local setup: `fareed@06`.
This only works if your MySQL `root` account already has that password. The project ZIP cannot change your MySQL server password. If MySQL Workbench currently connects with a different password, update `DB_PASSWORD` in `.env` to that real password.
